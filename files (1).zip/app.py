"""
Speech-to-Text + Translation Backend
Flask serves BOTH the HTML page AND the API — no CORS issues.

INSTALL:
    pip install flask flask-cors openai-whisper werkzeug

ALSO NEED ffmpeg:
    Mac:     brew install ffmpeg
    Windows: https://ffmpeg.org/download.html  (add to PATH)
    Linux:   sudo apt install ffmpeg

RUN:
    python app.py

THEN OPEN IN BROWSER:
    http://127.0.0.1:5000
    (Do NOT open index.html directly — always use this URL)
"""

from flask import Flask, request, jsonify, send_file, make_response
from flask_cors import CORS
import whisper
import os
from werkzeug.utils import secure_filename

# ─── App Setup ────────────────────────────────────────────
app = Flask(__name__)

# Belt-and-suspenders CORS for all routes
CORS(app, resources={r"/*": {"origins": "*"}},
     allow_headers=["Content-Type"],
     methods=["GET", "POST", "OPTIONS"])

# ─── Load Whisper ─────────────────────────────────────────
print("Loading Whisper model (base)...")
model = whisper.load_model("base")
print("✅ Whisper ready!\n")

# ─── Upload Config ────────────────────────────────────────
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
ALLOWED_EXTENSIONS = {"wav", "mp3", "m4a", "ogg", "webm", "flac"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def cors_headers(resp):
    resp.headers["Access-Control-Allow-Origin"]  = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "POST, GET, OPTIONS"
    return resp


# ─── Serve the Frontend ───────────────────────────────────
@app.route("/")
def index():
    """Serve the HTML frontend — same origin as API, so no CORS."""
    html_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "index.html")
    if os.path.exists(html_path):
        return send_file(html_path)
    return "<h2>index.html not found — put it in the same folder as app.py</h2>", 404


# ─── Health Check ─────────────────────────────────────────
@app.route("/ping")
def ping():
    return jsonify({"status": "ok", "message": "Backend is running!"})


# ─── Speech-to-Text ───────────────────────────────────────
@app.route("/speech-to-text", methods=["POST", "OPTIONS"])
def speech_to_text():
    if request.method == "OPTIONS":
        resp = make_response("", 204)
        return cors_headers(resp)

    file_path = None
    try:
        if "audio" not in request.files:
            return cors_headers(jsonify({"error": "No audio file in request"})), 400

        audio_file = request.files["audio"]
        if audio_file.filename == "":
            return cors_headers(jsonify({"error": "Empty filename"})), 400
        if not allowed_file(audio_file.filename):
            return cors_headers(jsonify({"error": f"Unsupported format"})), 400

        # Save
        filename  = secure_filename(audio_file.filename)
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        audio_file.save(file_path)
        print(f"📂 Saved: {file_path}  ({os.path.getsize(file_path)} bytes)")

        # Transcribe
        print("🔊 Transcribing...")
        result        = model.transcribe(file_path, fp16=False)
        original_text = result["text"].strip()
        detected_lang = result.get("language", "unknown")
        print(f"✅ Transcript : {original_text}")
        print(f"🌍 Detected   : {detected_lang}")

        if not original_text:
            original_text = "No speech detected"

        # NOTE: Translation is handled by the browser via MyMemory API.
        # Flask only transcribes — it no longer translates.
        os.remove(file_path)

        resp = jsonify({
            "original_text":     original_text,
            "detected_language": detected_lang,
        })
        return cors_headers(resp)

    except Exception as e:
        print(f"❌ Error: {e}")
        if file_path and os.path.exists(file_path):
            os.remove(file_path)
        return cors_headers(jsonify({"error": f"Processing failed: {e}"})), 500


# ─── /translate removed ───────────────────────────────────
# Translation now happens directly in the browser via MyMemory
# free public API — Flask is only used for Whisper transcription.


# ─── Run ──────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 55)
    print("  🚀  Speech Translator running!")
    print("  Open in browser → http://127.0.0.1:5000")
    print("  ⚠️   Do NOT open index.html as a file:// URL")
    print("=" * 55 + "\n")
    app.run(host="127.0.0.1", port=5000, debug=True)
